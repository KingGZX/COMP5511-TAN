## Environment Setting：

Python 3.8

torch

torchvision

pillow

matplotlib



## Test：

I upload resent model, so that you can directly load the model and test it.

**I'm not going to upload alexnet model, because this model is trained on my PC (MaxOS) and I don't know why the size is so huge. ResNet only takes up 45 MB but alexnet model take up 230 MB.**





## Run the program:

### For Task1

​	*Install all the dependencies above and **turn to "train.py" to run the python file**. It'll automatically download the CIFAR-10 dataset for you, then after 50 epochs training, the program will plot some figures about accuracy and loss. Finally, you will find a resnet18.pt file which saves the best model. So, you can use this model to do any CIFAR-10 classification problem.*



### For Task2

*Fisrt you should initialize the dataset, actually, renaming all the images.*

*So, you **turn to "InitDataset.py" and run the python file.***



####  for imbalanced dataset training:

​		*you **turn to "Task2Train.py" and run the file.***



#### for balanced dataset training:

​       *you need to enlarge the dataset fisrt, so you **run "EnlargeDataset.py"** .*

​       *Then you'll find, the with mask num and without mask num is same in all datasets.*

​       *Eventually, **run "Task2Train.py".***



*After training, the program will plot some figures about accuracy, loss and g-mean. It'll also save a alexnet.pt file.*




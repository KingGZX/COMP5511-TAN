'''
author: Zhexuan Gu
Date: 2022-11-29 13:11:45
LastEditTime: 2022-11-29 13:53:27
FilePath: /Assignment2/utils/EnlargeDataset.py
Description: Please implement
'''
from PIL import Image
from PIL import ImageOps
import os
import random

train_dir = "face_mask_detection-main/train"
valid_dir = "face_mask_detection-main/validation"
test_dir = "face_mask_detection-main/test"

def Data_Augmentation(dir:str):
    imagewithmask = len(os.listdir(os.path.join(dir, "with_mask")))
    imagewithoutmasknum = len(os.listdir(os.path.join(dir, "without_mask")))
    imagesavepath = os.path.join(dir, "without_mask")
    images_nom = os.listdir(os.path.join(dir, "without_mask"))
    imageswithoutmask = imagewithoutmasknum
    while imageswithoutmask < imagewithmask:
        # randomly select a without mask image
        idx = random.randint(1, imagewithoutmasknum - 1)
        image = Image.open(os.path.join(imagesavepath, images_nom[idx]))
        # randomly select a simple augmentation
        op = random.randint(1, 4)
        if op == 1:
            image = image.rotate(45)
        elif op == 2:
            image = image.rotate(135)
        elif op == 3:
            image = ImageOps.flip(image)
        elif op == 4:
            image = ImageOps.mirror(image)
        imageswithoutmask += 1
        image.save(os.path.join(imagesavepath, "image-" + str(imageswithoutmask) + ".png"))
        
Data_Augmentation(train_dir)
Data_Augmentation(valid_dir)
Data_Augmentation(test_dir)
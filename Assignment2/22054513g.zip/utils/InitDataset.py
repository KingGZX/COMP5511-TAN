'''
author: Zhexuan Gu
Date: 2022-11-29 13:48:41
LastEditTime: 2022-11-29 13:48:52
FilePath: /Assignment2/utils/InitDataset.py
Description: do nothing but rename all the images
'''
from MyDataset import init

init()
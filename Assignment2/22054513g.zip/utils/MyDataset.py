'''
author: Zhexuan Gu
Date: 2022-11-27 16:39:13
LastEditTime: 2022-11-29 13:43:40
FilePath: /Assignment2/utils/MyDataset.py
Description: create face_mask_detection dataset
'''
import os
from torchvision.io import read_image
from torch.utils.data import Dataset

"""
since the original dataset dosen't directly give us label
we need to label them manually

let 0 represents "without mask" while 1 respresents "mask"
"""

def rename(img_dir):
    mask_path = os.path.join(img_dir, "with_mask")
    images = os.listdir(mask_path)
    for  i, image in enumerate(images, start=0):
        os.rename(os.path.join(mask_path, image), os.path.join(mask_path, "image-" + str(i + 1) + ".png"))
    nomask_path = os.path.join(img_dir, "without_mask")
    images = os.listdir(nomask_path)
    for  i, image in enumerate(images, start=0):
        os.rename(os.path.join(nomask_path, image), os.path.join(nomask_path, "image-" + str(i + 1) + ".png"))


class FaceMaskDetectionDataset(Dataset):
    def __init__(self, img_dir, transform=None, target_transform=None) -> None:
        super().__init__()
        self.img_dir = img_dir
        self.transform = transform
        self.target_transform = target_transform
        self.masklen = len(os.listdir(os.path.join(self.img_dir, "with_mask")))
        self.nomasklen = len(os.listdir(os.path.join(self.img_dir, "without_mask")))
        
    def __len__(self):
        """
        take an example: pass the directory "../face.../train/"
        we should list all the imgs
        """
        return self.masklen + self.nomasklen
    
    def __getitem__(self, idx):
        img_path = None
        label = None
        mask_dir = "with_mask"
        nomask_dir = "without_mask"
        if idx < self.masklen:
            _path = mask_dir + "/" + "image-" + str(idx + 1) + ".png"
            img_path = os.path.join(self.img_dir, _path)
            label = 1
        else:
            _path = nomask_dir + "/" + "image-" + str(idx + 1 - self.masklen) + ".png"
            img_path = os.path.join(self.img_dir, _path)
            label = 0
        image = read_image(img_path)
        if self.transform:
            image = self.transform(image)
        if self.target_transform:
            label = self.target_transform(label)
        return image, label
    

"""
test code

instance = FaceMaskDetectionDataset("face_mask_detection-main/train")
print(instance[550])

"""
def init():
    train_dir = "face_mask_detection-main/train"
    valid_dir = "face_mask_detection-main/validation"
    test_dir = "face_mask_detection-main/test"
        
    rename(train_dir)
    rename(valid_dir)
    rename(test_dir)
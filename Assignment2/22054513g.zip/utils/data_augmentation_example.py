'''
author: Zhexuan Gu
Date: 2022-11-29 13:11:45
LastEditTime: 2022-11-29 15:06:02
FilePath: /Assignment2/utils/data_augmentation_example.py
Description: image augmentation visualization
'''

from PIL import Image
from PIL import ImageOps
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

image = Image.open("./utils/image-1.png")


imageflip = ImageOps.flip(image)
imageflip.save("./utils/image-1_flip.png")

imagerotate = image.rotate(15)
imagerotate.save("./utils/image-1_rotate.png")

imageresize = image.resize((32, 32))
imageresize.save("./utils/image-1_resize.png")

sub1 = mpimg.imread("./utils/image-1.png")
sub2 = mpimg.imread("./utils/image-1_flip.png")
sub3 = mpimg.imread("./utils/image-1_rotate.png")
sub4 = mpimg.imread("./utils/image-1_resize.png")

plt.subplot(2, 2, 1)
plt.axis("off")
plt.imshow(sub1)
plt.subplot(2, 2, 2)
plt.axis("off")
plt.imshow(sub2)
plt.subplot(2, 2, 3)
plt.axis("off")
plt.imshow(sub3)
plt.subplot(2, 2, 4)
plt.axis("off")
plt.imshow(sub4)

plt.show()
'''
author: Zhexuan Gu
Date: 2022-11-27 18:59:37
LastEditTime: 2022-11-29 14:19:50
FilePath: /Assignment2/utils/Task2Train.py
Description: train model
'''
import torch 
import torch.nn as nn
import torch.optim as opt
from torch.utils.data import sampler
import torch.nn.functional as F
import torchvision
from torch.utils.data import DataLoader
from torchvision.transforms import ToTensor
import torchvision.transforms as transforms
from MyDataset import FaceMaskDetectionDataset
from MyDataset import init
import matplotlib.pyplot as plt
from MyAlexNet import AlexNet


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
dtype = torch.float32

def G_Mean(loader, model, valid:bool):
    if valid:
        print('Checking G-Mean on validation set')
    else:
        print('Checking G-Mean on test set')   
    TP, FN, FP, TN = 0, 0, 0, 0
    model.eval()  # set model to evaluation mode
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device=device, dtype=dtype)  # move to device, e.g. GPU
            y = y.unsqueeze(1).float()
            y = y.to(device=device, dtype=torch.float)
            scores = model(x)
            preds = torch.round(scores)
            for j in range(len(y)):
                if y[j] == 1:
                    if preds[j] == 1:
                        TP += 1
                    else:
                        FN += 1
                else:
                    if preds[j] == 0:
                        TN += 1
                    else:
                        FP += 1
        TPR = TP / (TP + FN)
        TNR = TN / (TN + FP)
        GMEAN = (TPR * TNR) ** (1/2)
        print("TPR: %f\n, TNR: %f\n, GMEAN: %f\n" % (TPR, TNR, GMEAN))
    return GMEAN


def check_accuracy(loader:DataLoader, model, valid:bool):
    if valid:
        print('Checking accuracy on validation set')
    else:
        print('Checking accuracy on test set')   
    num_correct = 0
    num_samples = 0
    acc = 0
    model.eval()  # set model to evaluation mode
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device=device, dtype=dtype)  # move to device, e.g. GPU
            y = y.unsqueeze(1).float()
            y = y.to(device=device, dtype=torch.float)
            scores = model(x)
            preds = torch.round(scores)
            num_correct += (preds == y).sum()
            num_samples += preds.size(0)
        acc = float(num_correct) / num_samples
        print('Got %d / %d correct (%.2f)' % (num_correct, num_samples, 100 * acc))
    return acc


def train(loader:DataLoader, model, epochs:int, loader_val:DataLoader, loss_list:list, acc_list:list, gmeanlist:list):
    best_acc = 0.0

    # other hyperparameters setting 
    optimizer = opt.SGD(model.parameters(), lr=8e-5, momentum=0.9, weight_decay=5e-4)                  
    loss = None
    gmean = None
    model = model.to(device=device)
    
    loss_fn = nn.BCELoss()
    
    for epoch in range(epochs):
        print("---------------epoch %d--------------" % (epoch + 1))

        for t, (x, y) in enumerate(loader):

            x = x.to(device=device, dtype=dtype)  # move to device, e.g. GPU
            y = y.unsqueeze(1).float()
            y = y.to(device=device, dtype=torch.float)

            model.train(True)
            
            preds = model(x)
            
            loss = loss_fn(preds, y)
            
            # Zero out all of the gradients for the variables which the optimizer
            # will update.
            optimizer.zero_grad()

            # This is the backwards pass: compute the gradient of the loss with
            # respect to each  parameter of the model.
            loss.backward()

            # Actually update the parameters of the model using the gradients
            # computed by the backwards pass.
            optimizer.step()
            
            if t % 100 == 0:
                print('Iteration %d, loss = %.4f' % (t, loss.item()))
                acc = check_accuracy(loader_val, model, True)
                gmean = G_Mean(loader_val, model, True)
                print()

                if gmean > best_acc:
                  """
                  best_acc = acc
                  """
                  best_acc = acc
                  # save the model
                  torch.save(model, "./best_model_alexnet.pt")
                  
        loss_list.append(loss.item())
        acc_list.append(acc)
        gmeanlist.append(gmean)


if __name__ == "__main__":
    train_dir = "face_mask_detection-main/train"
    valid_dir = "face_mask_detection-main/validation"
    test_dir = "face_mask_detection-main/test"
    
    
    train_set = FaceMaskDetectionDataset(train_dir)
    valid_set = FaceMaskDetectionDataset(valid_dir)
    test_set = FaceMaskDetectionDataset(test_dir)
    
    
    train_loader = DataLoader(train_set, batch_size=64, shuffle=True)
    valid_loader = DataLoader(valid_set, batch_size=64, shuffle=True)
    test_loader = DataLoader(test_set, batch_size=64, shuffle=True)
    
    model = AlexNet(num_classes=1)
    
    loss_list, acc_list, gmean_list = [], [], []
    
    train(train_loader, model, 10, valid_loader, loss_list, acc_list, gmean_list)
    
    epoch = [i for i in range(10)]
    plt.subplot(1, 2, 1)
    plt.plot(epoch, acc_list)
    plt.xlabel("epoch")
    plt.ylabel("accuracy on validation set")

    plt.subplot(1, 2, 2)
    plt.plot(epoch, loss_list)
    plt.xlabel("epoch")
    plt.ylabel("loss on training set")
    plt.show()
    
    plt.plot(epoch, gmean_list)
    plt.xlabel("epoch")
    plt.ylabel("gmean on validation set")
    plt.show()